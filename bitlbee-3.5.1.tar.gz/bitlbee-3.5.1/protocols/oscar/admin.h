#ifndef __OSCAR_ADMIN_H__
#define __OSCAR_ADMIN_H__

#define AIM_CB_FAM_ADM 0x0007

/*
 * SNAC Family: Administrative Services.
 */
#define AIM_CB_ADM_ERROR 0x0001
#define AIM_CB_ADM_INFOCHANGE_REPLY 0x0005
#define AIM_CB_ADM_DEFAULT 0xffff

#endif /* __OSCAR_ADMIN_H__ */
