openssl s_client -host localhost -port 2727 -verify 0
