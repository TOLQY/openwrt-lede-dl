#!/bin/sh

autoreconf -fvi

