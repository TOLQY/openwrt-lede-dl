VERSION = (3, 1, 0)

from .backends import EmailBackend

default_app_config = 'post_office.apps.PostOfficeConfig'
