# following PEP 386
__version__ = "1.8.2"

default_app_config = 'statici18n.apps.StaticI18NConfig'
