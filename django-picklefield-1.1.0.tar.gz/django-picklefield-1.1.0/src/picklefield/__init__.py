"""Pickle field implementation for Django."""

DEFAULT_PROTOCOL = 2

from picklefield.fields import PickledObjectField  # noqa
