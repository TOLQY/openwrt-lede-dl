__author__ = 'Owais Lone'
__version__ = '0.6.0'

default_app_config = 'webpack_loader.apps.WebpackLoaderConfig'
