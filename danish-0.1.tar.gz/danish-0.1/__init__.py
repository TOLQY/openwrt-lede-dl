"""A daemon for middlebox DANE(RFC 6698) """

__author__ = 'Andrew McConachie'
__author_email__ = 'andrew@depht.com'
__license__ = 'GPL3'
__url__ = 'https://github.com/smutt/danish'
__version__ = '0.1'

import danish
