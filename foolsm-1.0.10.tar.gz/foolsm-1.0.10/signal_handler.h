/*

(C) 2009-2011 Mika Ilmaranta <ilmis@nullnet.fi>

License: GPLv2

*/

#ifndef __SIGNAL_HANDLER_H__
#define __SIGNAL_HANDLER_H__

void signal_handler(int signo);

#endif

/* EOF */
