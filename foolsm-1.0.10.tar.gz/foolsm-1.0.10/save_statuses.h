/*

(C) 2013 Mika Ilmaranta <ilmis@nullnet.fi>

License: GPLv2

*/

#ifndef __SAVE_STATUSES_H__
#define __SAVE_STATUSES_H__

void save_statuses(CONFIG *first);
void restore_statuses(CONFIG *first);

#endif

/* EOF */
