/*

  (C) 2014 Mika Ilmaranta <ilmis@nullnet.fi>

  License: GPLv2

*/

#ifndef __CMDLINE_H__
#define __CMDLINE_H__

void cmdline_parse(int argc, char *argv[]);

#endif

/* EOF */
