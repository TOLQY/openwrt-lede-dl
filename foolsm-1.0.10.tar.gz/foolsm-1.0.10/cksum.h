/*

(C) 2009-2011 Mika Ilmaranta <ilmis@nullnet.fi>

License: GPLv2

*/

#ifndef __CKSUM_H__
#define __CKSUM_H__

#include <sys/types.h>

int in_cksum(u_short *p, int n);

#endif

/* EOF */
