/*

  (C) 2014 Mika Ilmaranta <ilmis@nullnet.fi>

  License: GPLv2

*/

#ifndef __USAGE_H__
#define __USAGE_H__

void usage_and_exit(void);

#endif

/* EOF */
