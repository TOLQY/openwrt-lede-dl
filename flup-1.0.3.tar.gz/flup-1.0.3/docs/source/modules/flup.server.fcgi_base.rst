:mod:`flup.server.fcgi_base` - fcgi - a FastCGI/WSGI gateway
============================================================

.. automodule:: flup.server.fcgi_base
   :members:
   :undoc-members:
   :inherited-members:
