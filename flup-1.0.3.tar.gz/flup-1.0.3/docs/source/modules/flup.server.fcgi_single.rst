:mod:`flup.server.fcgi_single` - fcgi - a FastCGI/WSGI gateway (single-threaded)
================================================================================

.. automodule:: flup.server.fcgi_single
   :members:
   :undoc-members:
   :inherited-members:
